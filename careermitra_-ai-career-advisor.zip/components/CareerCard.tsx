
import React from 'react';
import { EnrichedRecommendation } from '../types';
import { BrainCircuitIcon, ChartBarIcon, RupeeIcon, GraduationCapIcon } from './icons';

interface CareerCardProps {
  recommendation: EnrichedRecommendation;
}

const CareerCard: React.FC<CareerCardProps> = ({ recommendation }) => {
  const { careerName, matchScore, explanation, marketData, requirements } = recommendation;

  const formatSalary = (salary: number) => {
    if (salary >= 100000) {
      return `₹${(salary / 100000).toFixed(1)} LPA`;
    }
    return `₹${salary.toLocaleString('en-IN')}`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300 ease-in-out transform hover:-translate-y-1 overflow-hidden flex flex-col h-full">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white pr-4">{careerName}</h3>
          <div className="flex-shrink-0 flex items-center bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full px-3 py-1 text-sm font-semibold">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            {matchScore}% Match
          </div>
        </div>

        <div className="mb-5 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
           <div className="flex items-start space-x-3">
             <BrainCircuitIcon className="h-5 w-5 text-blue-500 flex-shrink-0 mt-1" />
             <p className="text-sm text-gray-600 dark:text-gray-300">{explanation}</p>
           </div>
        </div>
        
        <div className="space-y-3 text-sm">
          <div className="flex items-center text-gray-700 dark:text-gray-300">
            <RupeeIcon className="h-5 w-5 mr-3 text-green-500"/>
            <span>Starting Salary: <strong className="font-semibold text-green-600 dark:text-green-400">{formatSalary(marketData.averageSalary.fresher)}</strong></span>
          </div>
          <div className="flex items-center text-gray-700 dark:text-gray-300">
            <ChartBarIcon className="h-5 w-5 mr-3 text-purple-500" />
            <span>Market Demand Score: <strong className="font-semibold text-purple-600 dark:text-purple-400">{marketData.demandScore}/100</strong></span>
          </div>
          <div className="flex items-center text-gray-700 dark:text-gray-300">
            <GraduationCapIcon className="h-5 w-5 mr-3 text-yellow-500" />
            <span>Education: <strong className="font-semibold text-yellow-600 dark:text-yellow-400">{requirements.minimumEducation}</strong></span>
          </div>
        </div>
      </div>
      <div className="bg-gray-50 dark:bg-gray-700/30 px-6 py-4">
        <button className="w-full bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
          Explore Pathway
        </button>
      </div>
    </div>
  );
};

const SkeletonCard: React.FC = () => (
  <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden animate-pulse flex flex-col h-full">
    <div className="p-6 flex-grow">
      <div className="flex justify-between items-start mb-4">
        <div className="h-6 bg-gray-300 dark:bg-gray-600 rounded w-3/4"></div>
        <div className="h-6 bg-gray-300 dark:bg-gray-600 rounded w-1/5"></div>
      </div>
      <div className="mb-5 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg space-y-2">
        <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-5/6"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-4/6"></div>
      </div>
      <div className="space-y-4 text-sm">
        <div className="flex items-center">
            <div className="h-5 w-5 mr-3 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-1/2"></div>
        </div>
        <div className="flex items-center">
            <div className="h-5 w-5 mr-3 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
            <div className="h-4 bg-gray-300 dark:bg-gray-600 rounded w-2/3"></div>
        </div>
      </div>
    </div>
    <div className="bg-gray-100 dark:bg-gray-700/30 px-6 py-4">
        <div className="h-10 bg-gray-300 dark:bg-gray-600 rounded-lg w-full"></div>
    </div>
  </div>
);

export { CareerCard, SkeletonCard };
