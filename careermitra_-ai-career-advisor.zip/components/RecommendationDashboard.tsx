
import React, { useState, useCallback } from 'react';
import { MOCK_STUDENT_PROFILE, MOCK_CAREER_MATCHES } from '../constants';
import { generateCareerExplanation } from '../services/geminiService';
import { EnrichedRecommendation } from '../types';
import { CareerCard, SkeletonCard } from './CareerCard';

const RecommendationDashboard: React.FC = () => {
  const [recommendations, setRecommendations] = useState<EnrichedRecommendation[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasGenerated, setHasGenerated] = useState(false);

  const handleGenerateRecommendations = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setHasGenerated(true);
    setRecommendations([]);

    try {
      const enrichedRecommendationsPromises = MOCK_CAREER_MATCHES.map(async (match) => {
        const explanation = await generateCareerExplanation(MOCK_STUDENT_PROFILE, match.career);
        return {
          ...match.career,
          matchScore: match.matchScore,
          explanation,
        };
      });

      const results = await Promise.all(enrichedRecommendationsPromises);
      setRecommendations(results);
    } catch (err) {
      console.error(err);
      setError('Failed to generate recommendations. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="w-full">
      <div className="text-center mb-8 md:mb-12">
        <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 dark:text-white">
          Hello, {MOCK_STUDENT_PROFILE.personalInfo.fullName}!
        </h2>
        <p className="mt-2 md:mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-300">
          Based on your unique profile, here are your personalized career recommendations, supercharged by AI.
        </p>
      </div>

      {!hasGenerated && (
         <div className="text-center bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md">
            <h3 className="text-xl font-semibold mb-4">Ready to Discover Your Future?</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">Click the button below to generate career paths perfectly tailored to you.</p>
            <button
                onClick={handleGenerateRecommendations}
                disabled={isLoading}
                className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-transform transform hover:scale-105"
                >
                {isLoading ? 'Generating...' : 'Generate My Career Matches'}
            </button>
         </div>
      )}

      {error && (
        <div className="text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-4 rounded-md">
          <p>{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-8 mt-8">
        {isLoading &&
          MOCK_CAREER_MATCHES.map((match) => <SkeletonCard key={match.career.careerId} />)
        }
        {!isLoading && recommendations.length > 0 &&
          recommendations.map((rec) => (
            <CareerCard key={rec.careerId} recommendation={rec} />
          ))
        }
      </div>
    </div>
  );
};

export default RecommendationDashboard;
