
import React from 'react';

export const BrainCircuitIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M12 5a3 3 0 0 1 3 3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1 -1v-2a5 5 0 0 0 -10 0v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1 -1v-2a3 3 0 0 1 3 -3z"></path>
    <path d="M10 14a1 1 0 0 0 -1 1v2a3 3 0 0 0 6 0v-2a1 1 0 0 0 -1 -1h-4z"></path>
    <path d="M15 19a1 1 0 0 0 1 1h2a3 3 0 0 0 3 -3v-2a1 1 0 0 0 -1 -1h-2a1 1 0 0 0 -1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1v-2a1 1 0 0 0 -1 -1h-2a1 1 0 0 0 -1 1v2a3 3 0 0 0 3 3h2a1 1 0 0 0 1 -1z"></path>
  </svg>
);

export const ChartBarIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M3 12m0 1a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z"></path>
    <path d="M9 8m0 1a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z"></path>
    <path d="M15 4m0 1a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v14a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z"></path>
    <path d="M4 20l14 0"></path>
  </svg>
);

export const RupeeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M18 5h-11h3a4 4 0 0 1 0 8h-3l6 6"></path>
    <path d="M7 9h11"></path>
  </svg>
);

export const GraduationCapIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
     <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
     <path d="M6 13.5l6 -3.5l6 3.5"></path>
     <path d="M18 10v4.5"></path>
     <path d="M12 11.5v8.5"></path>
     <path d="M6 13.5v3a1 1 0 0 0 .5 .866l5 3a1 1 0 0 0 1 0l5 -3a1 1 0 0 0 .5 -.866v-3"></path>
     <path d="M3 12l9 -5.5l9 5.5l-9 5.5z"></path>
  </svg>
);
